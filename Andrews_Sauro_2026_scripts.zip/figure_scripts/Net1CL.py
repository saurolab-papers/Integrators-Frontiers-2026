
import tellurium as te
import matplotlib
import matplotlib.pyplot as plt
from copy import deepcopy
import numpy as np
matplotlib.use('TkAgg')

model = te.loada('''

ext X

J1: X -> E; (V1 * X / (Km1 + X)) * (Ki / (Ki + P))
J2: E -> ; k2 * E
J3: E -> P; k_f * E
J4: P -> ; k_d

X = 2
E = 1
P = 0

V1 = 3
Km1 = 1
k2 = 1
k_f = 1 
k_d = 1
Ki = 1

at (time > 0): X = 6

''')

sim = model.simulate(-2, 6, 801, selections=['time', 'X', 'E', 'P'])

print(sim)

t = sim['time']
E0 = []
for _ in t:
    E0.append(1)

X = sim['X']
E = sim['E']
P = sim['P']

fig, ax1 = plt.subplots()
plt.ylim([0,1.5])

ax1.plot(t, X/10, c='green', linewidth = 2.5)
ax1.plot(t, E, c='blue', linewidth = 2.5)
ax1.plot(t, P, c='red', linewidth = 2.5)
ax1.plot(t, E0, linestyle="dashed", c='blue', linewidth = 2.5)

#ax1.set_ylabel('Concentration')
#ax1.set_xlabel('Time', size=16)
ax1.tick_params(axis='x', which='major', labelsize=0)
ax1.tick_params(axis='y', which='major', labelleft=0)


# ax1.legend(['X', 'E', 'P'])
# ax1.legend(['E', 'P'])
# plt.title('fig3b')
# plt.show()
plt.savefig("Net1CL",bbox_inches='tight')
