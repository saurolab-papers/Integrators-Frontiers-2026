
import tellurium as te
import matplotlib
import matplotlib.pyplot as plt
from copy import deepcopy
import numpy as np
matplotlib.use('TkAgg')

model = te.loada('''

ext X

J1: X -> E; k1 * X * P1
J2: E -> ; k2 * E
J3: -> P2; k_in * E
J4: -> P1; k_syn
J5: P1 -> ; k_bind * P1 * P2
J6: P2 -> ; k_bind * P1 * P2

X = 1
E = 1
P1 = 1
P2 = 1

k1 = 1
k2 = 1
k_in = 1 
k_syn = 1
k_bind = 1

at (time > 0): X = 3

''')

sim = model.simulate(-2, 6, 801, selections=['time', 'X', 'E', 'P1', 'P2'])

print(sim)

t = sim['time']
E0 = []
for _ in t:
    E0.append(1)

X = sim['X']
E = sim['E']
P1 = sim['P1']
P2 = sim['P2']

fig, ax1 = plt.subplots()
plt.rc('font',size=16)
plt.ylim([0,4])

ax1.plot(t, X/10, c='green', linewidth = 2.5)
ax1.plot(t, E, c='blue', linewidth = 2.5)
ax1.plot(t, P1, c='red', linewidth = 2.5)
ax1.plot(t, P2, c='purple', linewidth = 2.5)
ax1.plot(t, E0, linestyle="dashed", c='blue', linewidth = 2.5)

# ax1.set_ylabel('Concentration',size=16)
ax1.set_xlabel('Time',size=16)
ax1.tick_params(axis='x', which='major', labelsize=16)
ax1.tick_params(axis='y', which='major', labelleft=0)

# ax1.legend(['X', 'E', 'P1', 'P2'])
# ax1.legend(['E', 'P1', 'P2'])
# plt.title('fig3b')
# plt.show()
plt.savefig("Net4CL",bbox_inches='tight')

