
import tellurium as te
import matplotlib
import matplotlib.pyplot as plt
from copy import deepcopy
import numpy as np
matplotlib.use('TkAgg')

model = te.loada('''

ext X

J1: X -> E; V1 * X / (Km1 + X)
J2: E -> ; k2 * E
J3: S -> P; kf * E * S
J4: P -> S; kd

X = 0.5
E = 1
S = 1
P = 1

V1 = 3
Km1 = 1
k2 = 1
kf = 1
kd = 1

at (time > 0): X = 6

''')

sim = model.simulate(-2, 6, 200, selections=['time', 'X', 'E', 'P'])

print(sim)

t = sim['time']
E0 = []
for _ in t:
    E0.append(1)

X = sim['X']
E = sim['E']
P = sim['P']

fig, ax1 = plt.subplots()
plt.ylim([0,3])

ax1.plot(t, X/10, c='green', linewidth = 2.5)
ax1.plot(t, E, c='blue', linewidth = 2.5)
ax1.plot(t, P, c='red', linewidth = 2.5)
ax1.plot(t, E0, linestyle="dashed", c ='blue', linewidth = 2.5)

ax1.set_ylabel('Concentration',size=16)
#ax1.set_xlabel('Time',size=16)
ax1.tick_params(axis='x', which='major', labelsize=0)
ax1.tick_params(axis='y', which='major', labelsize=16)

# ax1.legend(['X', 'E', 'P'])
# ax1.legend(['E', 'P'])
# plt.title('fig3b')
# plt.show()
plt.savefig("Net3bOL",bbox_inches='tight')
